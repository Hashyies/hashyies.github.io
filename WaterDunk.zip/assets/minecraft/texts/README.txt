The EliteCreatures made by Sefreneth

Please take a moment to reag legal terms and conditions

There is a safety measure to stop stealing pack from our server. As you bought this pack, if you are experiencing issues remove it by: 

option 1: Rename folders in directory resourcepackname\assets\minecraft\models\item on resourcepackname\assets\minecraft\models\items (s matters)
						resourcepack\assets\minecraft\textures\item on resourcepack\assets\minecraft\textures\items
		Note for option 1, if you have any other models that are nto from Elitecraft, you may have to change texture traces in those models..how to do this in option 2

option2: Open each .json file in text editors prefrebly notepad and edit this line ;	
"textures": {
		"texturename": "item/texturename"     on "texturename": "items/texturename"

option3: Contact Sefreneth on discord Sefreneth
#2646 or any other disclosed contact

Also for the skeeving wretch that would like to breach terms and conditions: im watching you and my models are watermarket to if i catch you, i will get you down! mwhahaha